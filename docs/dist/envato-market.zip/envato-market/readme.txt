=== Envato Market ===
Website: https://www.envato.com/lp/market-plugin/
Contributors: valendesigns, dtbaker, aaronrutley
Requires at least: 5.1
Tested up to: 6.1
Stable tag: 2.0.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress Theme & Plugin management for the Envato Market.

== Description ==

Please see https://www.envato.com/lp/market-plugin/ for more details.
